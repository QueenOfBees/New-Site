file = open('./matrix.txt', 'r+')
import json

for row in file:
    ob = json.loads(row)
    print(ob)
    for key, value in ob.items():
        print(key, ' ', value)
