from imageai.Detection import ObjectDetection
import os
import numpy as np
import cv2
import copy
import random
from PIL import Image
import json


def cut():
    path_in = './predata/'
    path_out = './data/'
    i = 0
    for image in os.listdir(path_in):
        if image.endswith('jpg') or image.endswith('.png'):
            i = i + 1
            if 'A' in image:
                img = cv2.imread(os.path.join(path_in, image))
                a = img.shape
                box1 = (0, a[0] / 4, a[1], a[0] * 52 / 90)
                box2 = (0, a[0] * 52 / 90, a[1], a[0])
                img = Image.open(os.path.join(path_in, image))
                img1 = img.crop(box1)
                img2 = img.crop(box2)
                img1.save(os.path.join(path_out, str(i) + '_A1.jpg'))
                img2.save(os.path.join(path_out, str(i) + '_A2.jpg'))
            elif 'B' in image:
                img = cv2.imread(os.path.join(path_in, image))
                a = img.shape
                box1 = (0, a[0] * 3 / 10, a[1], a[0] * 3 / 7)
                box2 = (0, a[0] * 3 / 7, a[1], a[0])
                img = Image.open(os.path.join(path_in, image))
                img1 = img.crop(box1)
                img2 = img.crop(box2)
                img1.save(os.path.join(path_out, str(i) + '_B1.jpg'))
                img2.save(os.path.join(path_out, str(i) + '_B2.jpg'))
            elif 'C' in image:
                img = cv2.imread(os.path.join(path_in, image))
                a = img.shape
                box1 = (0, a[0] * 3 / 10, a[1], a[0] * 3 / 7)
                box2 = (0, a[0] * 3 / 7, a[1], a[0])
                img = Image.open(os.path.join(path_in, image))
                img1 = img.crop(box1)
                img2 = img.crop(box2)
                img1.save(os.path.join(path_out, str(i) + '_C1.jpg'))
                img2.save(os.path.join(path_out, str(i) + '_C2.jpg'))


cut()


def MapA(pot, x, y, key):
    specA = copy.deepcopy(A)
    for postion in pot:
        if (postion[1] <= y and postion[1] >= 0.65 * y):
            for i in range(13):
                if (postion[0] <= x * (i + 1) / 13 and postion[0] >= x * i / 13):
                    if (specA[0][i] == 'E'):
                        specA[0][i] = 'O'
                    else:
                        f1 = False
                        for ii in range(i - 1, i + 1):
                            if (ii <= 12 and ii >= 0 and specA[0][ii] == 'E' and f1 == False):
                                specA[0][ii] = 'O'
                                f1 = True
        elif postion[1] < 0.65 * y and postion[1] >= 0.55 * y:
            for i in range(13):
                if (postion[0] <= x * (i + 1) / 13 and postion[0] >= x * i / 13):
                    if (specA[1][i] == 'E'):
                        specA[1][i] = 'O'
                    else:
                        f1 = False
                        for ii in range(i - 1, i + 1):
                            if (ii <= 12 and ii >= 0 and specA[1][ii] == 'E' and f1 == False):
                                specA[1][ii] = 'O'
                                f1 = True
        elif (postion[1] < 0.55 * y and postion[1] >= 0.495 * y):
            for i in range(13):
                if (postion[0] <= x * (i + 1) / 13 and postion[0] >= x * i / 13):
                    if (specA[2][i] == 'E'):
                        specA[2][i] = 'O'
                    else:
                        f1 = False
                        for ii in range(i - 1, i + 1):
                            if (ii <= 12 and ii >= 0 and specA[2][ii] == 'E' and f1 == False):
                                specA[2][ii] = 'O'
                                f1 = True
        elif (postion[1] < 0.495 * y and postion[1] >= 0.46 * y):
            for i in range(13):
                if (postion[0] <= x * (i + 1) / 13 and postion[0] >= x * i / 13):
                    if (specA[3][i] == 'E'):
                        specA[3][i] = 'O'
                    else:
                        f1 = False
                        for ii in range(i - 1, i + 1):
                            if (ii <= 12 and ii >= 0 and specA[3][ii] == 'E' and f1 == False):
                                specA[3][ii] = 'O'
                                f1 = True
        elif (postion[1] < 0.46 * y and postion[1] >= 0.44 * y):
            for i in range(13):
                if (postion[0] <= x * (i + 1) / 13 and postion[0] >= x * i / 13):
                    if (specA[4][i] == 'E'):
                        specA[4][i] = 'O'
                    else:
                        f1 = False
                        for ii in range(i - 1, i + 1):
                            if (ii <= 12 and ii >= 0 and specA[4][ii] == 'E' and f1 == False):
                                specA[4][ii] = 'O'
                                f1 = True
        elif (postion[1] < 0.44 * y and postion[1] >= 0.43 * y):
            for i in range(13):
                if (postion[0] <= x * (i + 1) / 13 and postion[0] >= x * i / 13):
                    if (specA[5][i] == 'E'):
                        specA[5][i] = 'O'
                    else:
                        f1 = False
                        for ii in range(i - 1, i + 1):
                            if (ii <= 12 and ii >= 0 and specA[5][ii] == 'E' and f1 == False):
                                specA[5][ii] = 'O'
                                f1 = True
        elif (postion[1] < 0.43 * y and postion[1] >= 0.42 * y):
            for i in range(9):
                if (postion[0] <= x * (i + 5) / 13 and postion[0] >= x * (i + 4) / 13):
                    if (specA[6][i] == 'E'):
                        specA[6][i] = 'O'
                    else:
                        f1 = False
                        for ii in range(i - 1, i + 1):
                            if (ii <= 8 and ii >= 0 and specA[6][ii] == 'E' and f1 == False):
                                specA[6][ii] = 'O'
                                f1 = True
        elif (postion[1] < 0.42 * y and postion[1] >= 0.40 * y):
            for i in range(4):
                if (postion[0] <= x * (i + 10) / 13 and postion[0] >= x * (i + 9) / 13):
                    if (specA[7][i] == 'E'):
                        specA[7][i] = 'O'
                    else:
                        f1 = False
                        for ii in range(4):
                            if (specA[7][ii] == 'E' and f1 == False):
                                specA[7][ii] = 'O'
                                f1 = True


        else:
            fl = True
            while (fl):
                randrow = random.randint(6, 7)
                randcol = random.randint(0, 3)
                if (specA[randrow][randcol] == 'E'):
                    specA[randrow][randcol] = 'O'
                    f1 = False
    final[key[:-5]] = specA


def MapB(pot, x, y, key):
    specB = copy.deepcopy(B)
    for postion in pot:
        if (postion[1] <= y and postion[1] >= 0.7 * y):
            for i in range(13):
                if postion[0] <= x * (i + 1) / 13 and postion[0] >= x * i / 13:
                    if (specB[0][i] == 'E'):
                        specB[0][i] = 'O'
                    else:
                        f1 = False
                        for ii in range(i - 1, i + 1):
                            if (ii <= 12 and ii >= 0 and specB[0][ii] == 'E' and f1 == False):
                                specB[0][ii] = 'O'
                                f1 = True
        elif (postion[1] < 0.7 * y and postion[1] >= 0.6 * y):
            for i in range(13):
                if (postion[0] <= x * (i + 1) / 13 and postion[0] >= x * i / 13):
                    if (specB[1][i] == 'E'):
                        specB[1][i] = 'O'
                    else:
                        f1 = False
                        for ii in range(i - 1, i + 1):
                            if (ii <= 12 and ii >= 0 and specB[1][ii] == 'E' and f1 == False):
                                specB[1][ii] = 'O'
                                f1 = True
        elif (postion[1] < 0.6 * y and postion[1] >= 0.54 * y):
            for i in range(13):
                if (postion[0] <= x * (i + 1) / 13 and postion[0] >= x * i / 13):
                    if (specB[2][i] == 'E'):
                        specB[2][i] = 'O'
                    else:
                        f1 = False
                        for ii in range(i - 1, i + 1):
                            if (ii <= 12 and ii >= 0 and specB[2][ii] == 'E' and f1 == False):
                                specB[2][ii] = 'O'
                                f1 = True
        elif (postion[1] < 0.54 * y and postion[1] >= 0.5 * y):
            for i in range(13):
                if (postion[0] <= x * (i + 1) / 13 and postion[0] >= x * i / 13):
                    if (specB[3][i] == 'E'):
                        specB[3][i] = 'O'
                    else:
                        f1 = False
                        for ii in range(i - 1, i + 1):
                            if (ii <= 12 and ii >= 0 and specB[3][ii] == 'E' and f1 == False):
                                specB[3][ii] = 'O'
                                f1 = True
        elif (postion[1] < 0.5 * y and postion[1] >= 0.47 * y):
            for i in range(13):
                if (postion[0] <= x * (i + 1) / 13 and postion[0] >= x * i / 13):
                    if (specB[4][i] == 'E'):
                        specB[4][i] = 'O'
                    else:
                        f1 = False
                        for ii in range(i - 1, i + 1):
                            if (ii <= 12 and ii >= 0 and specB[4][ii] == 'E' and f1 == False):
                                specB[4][ii] = 'O'
                                f1 = True
        elif (postion[1] < 0.47 * y and postion[1] >= 0.445 * y):
            for i in range(13):
                if (postion[0] <= x * (i + 1) / 13 and postion[0] >= x * i / 13):
                    if (specB[5][i] == 'E'):
                        specB[5][i] = 'O'
                    else:
                        f1 = False
                        for ii in range(i - 1, i + 1):
                            if (ii <= 12 and ii >= 0 and specB[5][ii] == 'E' and f1 == False):
                                specB[5][ii] = 'O'
                                f1 = True
        elif (postion[1] < 0.445 * y and postion[1] >= 0.43 * y):
            for i in range(13):
                if (postion[0] <= x * (i + 1) / 13 and postion[0] >= x * i / 13):
                    if (specB[6][i] == 'E'):
                        specB[6][i] = 'O'
                    else:
                        f1 = False
                        for ii in range(i - 1, i + 1):
                            if (ii <= 12 and ii >= 0 and specB[6][ii] == 'E' and f1 == False):
                                specB[6][ii] = 'O'
                                f1 = True
        elif (postion[1] < 0.43 * y and postion[1] >= 0.415 * y):
            for i in range(13):
                if (postion[0] <= x * (i + 1) / 13 and postion[0] >= x * i / 13):
                    if (specB[7][i] == 'E'):
                        specB[7][i] = 'O'
                    else:
                        f1 = False
                        for ii in range(i - 1, i + 1):
                            if (ii <= 12 and ii >= 0 and specB[7][ii] == 'E' and f1 == False):
                                specB[7][ii] = 'O'
                                f1 = True
        elif (postion[1] < 0.415 * y and postion[1] >= 0.39 * y):
            for i in range(13):
                if (postion[0] <= x * (i + 1) / 13 and postion[0] >= x * i / 13):
                    if (specB[8][i] == 'E'):
                        specB[8][i] = 'O'
                    else:
                        f1 = False
                        for ii in range(i - 1, i + 1):
                            if (ii <= 12 and ii >= 0 and specB[8][ii] == 'E' and f1 == False):
                                specB[8][ii] = 'O'
                                f1 = True
        elif (postion[1] < 0.39 * y and postion[1] >= 0.37 * y):
            for i in range(13):
                if (postion[0] <= x * (i + 1) / 13 and postion[0] >= x * i / 13):
                    if (specB[9][i] == 'E'):
                        specB[9][i] = 'O'
                    else:
                        f1 = False
                        for ii in range(i - 1, i + 1):
                            if (ii <= 12 and ii >= 0 and specB[9][ii] == 'E' and f1 == False):
                                specB[9][ii] = 'O'
                                f1 = True
        elif (postion[1] < 0.37 * y and postion[1] >= 0.35 * y):
            for i in range(13):
                if (postion[0] <= x * (i + 1) / 13 and postion[0] >= x * i / 13):
                    if (specB[10][i] == 'E'):
                        specB[10][i] = 'O'
                    else:
                        f1 = False
                        for ii in range(i - 1, i + 1):
                            if (ii <= 12 and ii >= 0 and specB[10][ii] == 'E' and f1 == False):
                                specB[10][ii] = 'O'
                                f1 = True
        elif (postion[1] < 0.35 * y and postion[1] >= 0.345 * y):
            for i in range(10):
                if (postion[0] <= x * (i + 4) / 13 and postion[0] >= x * (i + 3) / 13):
                    if (specB[11][i] == 'E'):
                        specB[11][i] = 'O'
                    else:
                        f1 = False
                        for ii in range(i - 1, i + 1):
                            if (ii <= 9 and ii >= 0 and specB[11][ii] == 'E' and f1 == False):
                                specB[11][ii] = 'O'
                                f1 = True
        elif (postion[1] < 0.345 * y and postion[1] >= 0.34 * y):
            for i in range(3):
                if (postion[0] <= x * (i + 11) / 13 and postion[0] >= x * (i + 10) / 13):
                    if (specB[12][i] == 'E'):
                        specB[12][i] = 'O'
                    else:
                        f1 = False
                        for ii in range(3):
                            if (specB[12][ii] == 'E' and f1 == False):
                                specB[12][ii] = 'O'
                                f1 = True
        else:
            fl = True
            while (fl):
                randrow = random.randint(0, 2)
                randcol = random.randint(0, 2)
                if (specB[randrow][randcol] == 'E'):
                    specB[randrow][randcol] = 'O'
                    f1 = False
    final[key[:-5]] = specB


def compare(i, j, maxy1):
    x1 = (i[0] + i[2]) / 2
    y1 = i[3]
    x2 = (j[0] + j[2]) / 2
    y2 = j[1]
    if (abs(x1 - x2) < 20 and abs(y2) < 5 and abs(y1 - maxy1) < 5):
        return False
    else:
        return True


def handle(a, b, key, p1):
    pot = []
    flag = True
    maxy1 = p1[0]
    for i in a:
        x1 = (i[0] + i[2]) / 2
        y1 = (i[1] + i[3]) / 2
        if ('A' in key):
            pot.append((x1, y1 + 45 * maxy1 / 59))
        elif ('B' in key):
            pot.append((x1, y1 + 7 * maxy1 / 3))
    for j in b:
        x2 = (j[0] + j[2]) / 2
        y2 = (j[1] + j[3]) / 2
        for i in a:
            if (compare(i, j, maxy1)):
                flag = False
        if (flag == True and 'A' in key):
            pot.append((x2, y2 + 104 * maxy1 / 59))
        elif (flag == True and 'B' in key):
            pot.append((x2, y2 + 10 * maxy1 / 3))
    Acount[key[:-5]] = len(pot)
    if ('A' in key):
        MapA(pot, p1[1], 180 * maxy1 / 59, key)
    elif ('B' in key):
        MapB(pot, p1[1], 70 * maxy1 / 9, key)


path_in = './data/'
execution_path = os.getcwd()
images = []
final = {}
finalcount = {}
A1size = []
B1size = []
Acount = {}
A1 = {}
A2 = {}
B1 = {}
B2 = {}
A = [['E' for i in range(13)] for j in range(6)]
A.append(['E' for i in range(9)])
A.append(['E' for i in range(4)])
B = [['E' for i in range(13)] for j in range(11)]
B.append(['E' for i in range(10)])
B.append(['E' for i in range(3)])
for image in os.listdir(path_in):
    images.append(image)
detector = ObjectDetection(x=800, y=1333)
detector.setModelTypeAsRetinaNet()
detector.setModelPath(os.path.join(execution_path, "../C_1/resnet50_coco_best_v2.0.1.h5"))
detector.loadModel()
for i in range(len(images)):
    if ('A1' in images[i]):
        img = cv2.imread(os.path.join(path_in, images[i]))
        a = img.shape
        A1size.append(a[0])
        A1size.append(a[1])
        detector.loadModel(detection_speed="fast")
        detections, boxs = detector.detectCustomObjectsFromImage(detector.CustomObjects(person=True),
                                                                 input_image=os.path.join(path_in,
                                                                                          images[i]))
        A1[images[i]] = boxs
    elif ('A2' in images[i]):
        """img = cv2.imread(os.path.join(path_in, images[i]))
        a = img.shape
        A2size.append(a[0])
        A2size.append(a[1])"""
        detector.loadModel(detection_speed="normal")
        detections, boxs = detector.detectCustomObjectsFromImage(detector.CustomObjects(person=True),
                                                                 input_image=os.path.join(path_in,
                                                                                          images[i]))
        A2[images[i]] = boxs
    elif ('B1' in images[i]):
        img = cv2.imread(os.path.join(path_in, images[i]))
        a = img.shape
        B1size.append(a[0])
        B1size.append(a[1])
        detector.loadModel(detection_speed="fast")
        detections, boxs = detector.detectCustomObjectsFromImage(detector.CustomObjects(person=True),
                                                                 input_image=os.path.join(path_in,
                                                                                          images[i]))

        B1[images[i]] = boxs
    elif ('B2' in images[i]):
        """img = cv2.imread(os.path.join(path_in, images[i]))
        a = img.shape
        B2size.append(a[0])
        B2size.append(a[1])"""
        detector.loadModel(detection_speed="normal")
        detections, boxs = detector.detectCustomObjectsFromImage(detector.CustomObjects(person=True),
                                                                 input_image=os.path.join(path_in,
                                                                                          images[i]))
        B2[images[i]] = boxs
for key in A1.keys():
    for key1 in A2.keys():
        if (key1[:-7] == key[:-7]):
            a = np.array(A1[key]).astype(int)
            b = np.array(A2[key1]).astype(int)
            handle(a, b, key, A1size)
for key2 in B1.keys():
    for key3 in B2.keys():
        if (key2[:-7] == key3[:-7]):
            a = np.array(B1[key2]).astype(int)
            b = np.array(B2[key3]).astype(int)
            handle(a, b, key2, B1size)


def save2file(this, that):
    pre = []
    for x in this.values():
        pre.append(x)
    print(pre)
    list = pre[0]
    row_num = len(list)
    col_num = len(list[0])  # 第一行为列数
    out_string = []
    for row in list:
        row.insert(3, '_')
        last_insert_index = len(row) - 3
        row.insert(last_insert_index, '_')
        string = ''.join(row)
        out_string.append(string)
        out_string.append(' ')
    out_string = ''.join(out_string)
    # 得到json字符串输出
    python_dict = {
        'classroom': '1a101',
        'row': row_num,
        'col': col_num,
        'chart': out_string,
        'people': that,
    }
    写入方式 = 'a+'
    json_string = json.dumps(python_dict)
    输出 = open('matrix.txt', 写入方式)  # a+ to
    输出.writelines(json_string)
    输出.close()


save2file(final, list(Acount.values())[0])
# Author
章玲君 = True
刘蒙蒙 = True
